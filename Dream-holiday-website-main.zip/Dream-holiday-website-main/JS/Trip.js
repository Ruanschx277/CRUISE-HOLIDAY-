$(document).ready(function(){
    $.ajax({
        type:"GET",
        URL:"",
success: function(data){
    temp - data;
}


    
    })
    })

    
      